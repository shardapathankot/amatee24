<body topmargin="0" rightmargin="0" bottommargin="0" leftmargin="0" marginwidth="0" marginheight="0" width="100%" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%; height: 100%; -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%;
	background-color: #F0F0F0;
	color: #000000; padding-top: 5rem;" bgcolor="#F0F0F0" text="#000000">

    <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0"
        style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%;" class="background">
        <tr>
            <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;"
                bgcolor="#F0F0F0">

                <table border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#FFFFFF" width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
	            max-width: 760px;" class="container">

                    <tr>
                        <td>
                            <table style="    width: 95%;
                            margin: 1rem auto 1rem;
                            border: 1px solid #939393;
                            padding: 0px 0px;">
                                <tr>
                                    <td align="center" valign="top" style="border-collapse: collapse;
                                    border-spacing: 0;
                                    margin: 0;
                                    padding: 0;
                                    padding-bottom: 0px;
                                    width: 100%;
                                    display: block;
                                    font-size: 14px;
                                    font-weight: 500;
                                    text-align: center;
                                    letter-spacing: 2px;
                                    padding-top: 40px;
                                    color: #000000;
                                    font-family: sans-serif;line-height: 23px;" class="subheader">
                                        Thanks for accepting the invitation for our Wedding.

                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" valign="top" style="border-collapse: collapse;
                                    border-spacing: 0;
                                    margin: 0;
                                    padding: 0;
                                    padding-bottom: 0px;
                                    width: 100%;
                                    display: block;
                                    font-size: 14px;
                                    font-weight: 500;
                                    text-align: center;
                                    letter-spacing: 2px;
                                    padding-top: 40px;
                                    color: #000000;
                                    font-family: sans-serif; line-height: 23px;" class="subheader">
                                        Please keep the QR with you to attend the event
                                        <br />
                                        <br />
                                        <p><a href="{{qr_url}}" target="_blank">QR url link</a></p>
                                        
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td align="center" valign="top" style="border-collapse: collapse;
                                    border-spacing: 0;
                                    margin: 0;
                                    padding: 0;
                                    padding-bottom: 40px;
                                    width: 100%;
                                    display: block;
                                    font-size: 14px;
                                    font-weight: 500;
                                    text-align: center;
                                    letter-spacing: 2px;
                                    padding-top: 40px;
                                    color: #000000;
                                    font-family: sans-serif;" class="subheader">
                                        <img src="{{qr_image}}" alt="">
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                </table>

                <table border="0" cellpadding="0" cellspacing="0" align="center" width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
	max-width: 560px;" class="wrapper">

                    <tr>
                        <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
			padding-top: 25px;" class="social-icons">
                            <table width="256" border="0" cellpadding="0" cellspacing="0" align="center"
                                style="border-collapse: collapse; border-spacing: 0; padding: 0;">
                                <tr>

                                <tr>
                                    <td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 13px; font-weight: 400; line-height: 150%;
			padding-top: 20px;
			padding-bottom: 20px;
			color: #999999;
			font-family: sans-serif;" class="footer">


                                        <img width="1" height="1" border="0" vspace="0" hspace="0"
                                            style="margin: 0; padding: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; border: none; display: block;"
                                            src="" />

                                    </td>
                                </tr>

                            </table>

                        </td>
                    </tr>
                </table>

</body>