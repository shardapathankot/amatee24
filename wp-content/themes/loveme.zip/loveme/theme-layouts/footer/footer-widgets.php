<?php if( loveme_footer_widgets() ) {
?>
<!-- Footer Widgets -->
<div class="wpo-upper-footer">
	<div class="footer-widget-area">
		<div class="container-fluid">
			<div class="row">
				<div class="separator"></div>
				<?php echo loveme_footer_widgets(); ?>
			</div>
		</div>
	</div>
</div>
<!-- Footer Widgets -->
<?php
}