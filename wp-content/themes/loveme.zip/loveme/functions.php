<?php
/*
 * Loveme Theme's Functions
 * Author & Copyright:wpoceans
 * URL: http://themeforest.net/user/wpoceans
 */

/**
 * Define - Folder Paths
 */

define( 'LOVEME_THEMEROOT_URI', get_template_directory_uri() );
define( 'LOVEME_CSS', LOVEME_THEMEROOT_URI . '/assets/css' );
define( 'LOVEME_IMAGES', LOVEME_THEMEROOT_URI . '/assets/images' );
define( 'LOVEME_SCRIPTS', LOVEME_THEMEROOT_URI . '/assets/js' );
define( 'LOVEME_FRAMEWORK', get_template_directory() . '/includes' );
define( 'LOVEME_LAYOUT', get_template_directory() . '/theme-layouts' );
define( 'LOVEME_CS_IMAGES', LOVEME_THEMEROOT_URI . '/includes/theme-options/framework-extend/images' );
define( 'LOVEME_CS_FRAMEWORK', get_template_directory() . '/includes/theme-options/framework-extend' ); // Called in Icons field *.json
define( 'LOVEME_ADMIN_PATH', get_template_directory() . '/includes/theme-options/cs-framework' ); // Called in Icons field *.json

/**
 * Define - Global Theme Info's
 */
if (is_child_theme()) { // If Child Theme Active
	$loveme_theme_child = wp_get_theme();
	$loveme_get_parent = $loveme_theme_child->Template;
	$loveme_theme = wp_get_theme($loveme_get_parent);
} else { // Parent Theme Active
	$loveme_theme = wp_get_theme();
}
define('LOVEME_NAME', $loveme_theme->get( 'Name' ));
define('LOVEME_VERSION', $loveme_theme->get( 'Version' ));
define('LOVEME_BRAND_URL', $loveme_theme->get( 'AuthorURI' ));
define('LOVEME_BRAND_NAME', $loveme_theme->get( 'Author' ));

/**
 * All Main Files Include
 */
require_once( LOVEME_FRAMEWORK . '/init.php' );